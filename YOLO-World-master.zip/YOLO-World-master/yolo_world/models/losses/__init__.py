# Copyright (c) Tencent Inc. All rights reserved.
from .dynamic_loss import CoVMSELoss

__all__ = ['CoVMSELoss']
