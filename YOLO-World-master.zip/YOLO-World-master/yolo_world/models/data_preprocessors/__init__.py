# Copyright (c) Tencent Inc. All rights reserved.
from .data_preprocessor import YOLOWDetDataPreprocessor

__all__ = ['YOLOWDetDataPreprocessor']
