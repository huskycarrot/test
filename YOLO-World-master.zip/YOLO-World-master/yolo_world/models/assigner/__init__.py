from .task_aligned_assigner import YOLOWorldSegAssigner

__all__ = ['YOLOWorldSegAssigner']